<?php
/**
 * Plugin Name: ترب النتور
 * Description: المان های اختصاصی ترب برای المنتور.
 * Plugin URI:  https://vistaapp.ir/
 * Version:     1.0.0
 * Author:     ویستا
 * Author URI:  https://vistaapp.ir/
 * Text Domain: elementor-test-addon
 *
 * Elementor tested up to: 3.7.0
 * Elementor Pro tested up to: 3.7.0
 */

function register_torob_commercial_rows( $widgets_manager ) {

    require_once( __DIR__ . '/widgets/torob-widget.php' );


    $widgets_manager->register( new \Elementor_torob_commercial_rows_Widget() );

}
add_action( 'elementor/widgets/register', 'register_torob_commercial_rows' );